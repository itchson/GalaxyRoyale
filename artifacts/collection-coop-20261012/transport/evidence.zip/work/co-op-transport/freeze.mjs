import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root=path.resolve(new URL('../..',import.meta.url).pathname.replace(/^\/([A-Za-z]:)/,'$1'));
const directory=path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/,'$1'));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const commit='4cb003b167672326d01e77928f084ae1f29689fa';
const sources=execFileSync('git',['-C',root,'diff-tree','--no-commit-id','--name-only','-r','4f89b53'],{encoding:'utf8'}).trim().split(/\r?\n/);
const committed={},working={},inputs={},evidence={};
for(const name of sources) {
 committed[name]=sha(execFileSync('git',['-C',root,'show',commit+':'+name]));
 working[name]=sha(await fs.readFile(path.join(root,name)));
}
for(const name of ['apps/coop/server.mjs','apps/coop/store.mjs','package.json','pnpm-lock.yaml','tsconfig.json']) inputs[name]=sha(await fs.readFile(path.join(root,name)));
for(const name of ['HANDOFF.md','AMENDMENT.md','NATIVE_OPEN_AMENDMENT.md','final-test.log','amendment-final-test.log','native-open-test.log','checks.json','first-test.log','second-test.log','third-test.log','fourth-test.log','fifth-test.log','sixth-test.log','native-compatibility.json','native-compatibility.log','segment-compatibility.json','segment-compatibility.log','check-native.mjs','check-segments.mjs','stage-native-open/manifest.json','stage-native-open/modules/wire.js','stage-native-open/modules/signaling.js','stage-native-open/modules/transport.js','stage-native-open/review.js','stage-native-open/review.html']) evidence[name]=sha(await fs.readFile(path.join(directory,name)));
for(const name of await fs.readdir(path.join(directory,'native-fixtures'))) evidence['native-fixtures/'+name]=sha(await fs.readFile(path.join(directory,'native-fixtures',name)));
await fs.writeFile(path.join(directory,'manifest.json'),JSON.stringify({version:1,commit,parent:'38742784f6000135a68354750bdf0d3204334422',baseline:'5aa5cfaeb4db4e71511ac4dc251ce17d1b423923',committed,working,inputs,evidence},null,2)+'\n');
console.log(JSON.stringify({sources:sources.length,inputs:Object.keys(inputs).length,evidence:Object.keys(evidence).length,manifest_sha256:sha(await fs.readFile(path.join(directory,'manifest.json'))),handoff_sha256:sha(await fs.readFile(path.join(directory,'HANDOFF.md'))),amendment_sha256:sha(await fs.readFile(path.join(directory,'AMENDMENT.md')))}));
