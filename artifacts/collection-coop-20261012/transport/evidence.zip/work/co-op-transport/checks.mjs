import fs from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
const commands=[['typecheck','node',['node_modules/typescript/bin/tsc','--noEmit']],['diff','git',['diff','--check']]];
const result=[];
for(const [name,cmd,args] of commands) {
 const start=performance.now(),r=spawnSync(cmd,args,{encoding:'utf8'});
 result.push({name,command:[cmd,...args],exit_code:r.status,duration_ms:performance.now()-start,stdout:r.stdout,stderr:r.stderr});
 if(r.error||r.status!==0) throw Error('Meaningful check failed: '+name);
}
await fs.writeFile(new URL('./checks.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result.map(({stdout,stderr,...r})=>r)));
