import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
const sourceRoot='C:/Users/mitch/Documents/ChatGPT/galaxy-royale';
const stage=path.join(sourceRoot,'work/co-op-transport/stage-open');
const target=new URL('./browser-success/',import.meta.url);
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const sourceCommit='4cb003b167672326d01e77928f084ae1f29689fa';
const nativeManifest=JSON.parse(await fs.readFile(path.join(stage,'manifest.json'),'utf8'));
const candidatePins={};
for(const [name,hash] of Object.entries(nativeManifest.inputs)) {
 const live=await fs.readFile(path.join(sourceRoot,name));
 if(sha(live)!==hash) throw Error('Actual prepared source differs');
 const candidate=execFileSync('git',['-C',sourceRoot,'show',sourceCommit+':'+name]);
 const integrated=execFileSync('git',['-C',sourceRoot,'show','HEAD:'+name]);
 if(!candidate.equals(integrated)) throw Error('Integrated source differs from candidate');
 candidatePins[name]={prepared_raw_sha256:hash,committed_sha256:sha(candidate)};
}
await fs.mkdir(target,{recursive:true});
await fs.copyFile(path.join(stage,'manifest.json'),new URL('prepared-manifest.json',target));
const observations=[],pins={};
for(const name of await fs.readdir(path.join(stage,'captures'))) {
 const bytes=await fs.readFile(path.join(stage,'captures',name)), o=JSON.parse(bytes);
 if(!name.endsWith('-'+sha(bytes)+'.json')) throw Error('Capture name/content hash differs');
 if(JSON.stringify(o.source_inputs)!==JSON.stringify(nativeManifest.inputs)) throw Error('Capture source differs');
 if(Object.keys(o).some(k=>!['version','run_id','checks','created','closed','secure_context','rtc_available','rtc_errors','source_inputs','captured_at','scope'].includes(k))) throw Error('Unexpected capture key');
 if(o.checks.some(c=>!c.passed)) throw Error('Captured native failure');
 await fs.writeFile(new URL(name,target),bytes,{flag:'wx'});
 pins[name]=sha(bytes); observations.push({captured_at:o.captured_at,created:o.created,closed:o.closed,checks:o.checks.map(c=>c.name),rtc_errors:o.rtc_errors});
}
observations.sort((a,b)=>a.captured_at.localeCompare(b.captured_at));
const report={candidate:sourceCommit,integrated_head:execFileSync('git',['-C',sourceRoot,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),scope:'Root CUA-driven actual same-page native RTC; independently read exact retained reports, no independent browser control',candidatePins,pins,observations};
await fs.writeFile(new URL('inspection.json',target),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
