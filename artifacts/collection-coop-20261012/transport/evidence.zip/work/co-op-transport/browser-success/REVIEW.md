# Actual local RTC transport evidence

Root drove five visible controls in the IAB; this reviewer independently read and copied the five immutable sanitized reports. Run `d77a95f3698ca9ec`,2026-10-11T16:43:30.686Z–16:43:56.949Z. Exact candidate `4cb003b167672326d01e77928f084ae1f29689fa`; integrated observed head `fb45246d123e7e50cb0618648acc1396ec62919b`. Prepared working-byte hashes match actual Root files; committed source blobs match the candidate. CRLF checkout bytes differ from canonical LF blobs intentionally,with both identities retained in inspection.json. No browser control or game execution by this reviewer.

| Visible action | Actual report observation |
| --- | --- |
| Connect |2 native peers created,0 closed; real-channel-ready;admission pending |
| Join/input fixture |Join bound to authenticated peer;input refused before admission;fixture admission and input delivered;simulation waiting |
| Host end |2 created/2 closed;host-end-clean passed;Root additionally observed0 pending requests/timers in visible diagnostics |
| Rejoin |4 created/2 closed;distinct session and fresh pending admission;two new real peers ready |
| Dispose |4 created/4 closed;dispose-clean passed;Root additionally observed0 pending requests/timers |

All declared checks passed;the fixture admission is explicit and no Rust Game/profile/save is loaded. This proves two actual RTCPeerConnection clients and ordered DataChannel transport on **one page** using the real ephemeral HTTP signaling service. It does not prove separate browsers/devices/NAT/TURN/multiple networks,host+7 native browser peers,remote renderer,timing under real load,hidden/mobile recovery or playable co-op. The seven-guest topology remains actual HTTP +injected RTC model evidence from the focused suite,not this browser run.

Connect/send had no reported RTC error details. Host-end produced the allowlisted `sctp-failure`;Root's visible guest reason was channel_error after deliberate abrupt remote closure. It did not prevent delivery,terminal cleanup or rejoin. Rejoin reset the error history. Future player-facing copy should say **Connection ended** for an unclassified channel error and retain errorDetail only in diagnostics;do not assert host departure from SCTP error alone. A specific Host ended reason needs the authenticated session terminal notice or an explicit bounded graceful-end protocol. This is a presentation/lifecycle follow-up,not a remaining failure of this local transport proof.

The two previous browser attempts (Origin-less403 and second channel-error run) remain Root-owned historical captures. No claim that the open-event guard causally explains all failures;the final same-source actual run is the success evidence. Native-source compatibility separately covers8pilots/180shots and real naturally spawned Coil segment metadata;no body or simulation snapshot was rendered over RTC here.

No continuing listener was launched by this reviewer. Root reports the verified QA listener stopped after capture. Raw files are byte-identical copies,filename SHA256 matches content and all source_inputs match the prepared manifest. The unchanged owner freeze manifest9001d1dd… is separate from this browser evidence manifest.

Evidence note: earlier silent PowerShell Tee commands produced no typecheck.log/amendment-typecheck.log despite execution. Final `checks.json` records the actual successful TypeScript process exit0 and diff exit0;there is no invented historical log file.
