import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';
import {encode,decode,spec} from '../../apps/game/src/coop/wire.ts';
const location = 'C:/Users/mitch/.codex/worktrees/galaxy-hud-navigation/galaxy-royale/work/co-op-authority/serialization';
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const pins={}, values={};
for(const name of ['snapshot','entities','body','admissions','input']) {
 const bytes=await fs.readFile(path.join(location,name+'.json'));
 pins[name]={sha256:sha(bytes),bytes:bytes.length}; values[name]=JSON.parse(bytes);
}
const s=values.snapshot;
const checked=[];
for(const [kind,payload] of [['snapshot',s],['body',values.entities],['body',values.body],['input',values.input]]) {
 const encoded=encode({v:1,session:s.session,seq:1,kind,payload});
 if(JSON.stringify(decode(encoded).payload)!==JSON.stringify(payload)) throw Error('Native JSON changed');
 checked.push({kind,bytes:Buffer.byteLength(encoded)});
}
for(const p of s.participants) spec({local_seed:p.local_seed,identity:p.identity});
for(const a of values.admissions.slice(1)) {
 encode({v:1,session:s.session,seq:1,kind:'admission',payload:{accepted:true,slot:a.slot,epoch:a.epoch}});
}
for(const [kind,value] of [['entities',values.entities],['body',values.body]]) {
 encode({v:1,session:s.session,seq:1,kind:'body-query',payload:{kind,expected_revision:value.revision,offset:value.offset,...(kind==='body'?{id:value.id}:{})}});
}
const report={scope:'actual native API exported JSON through exact transport validators; no RTC execution',pins,checked,participants:s.participants.length,projectiles:s.projectiles.length,entity_rows:values.entities.entities.length,body_cells:values.body.cells.length,revision:s.revision,admissions:values.admissions.length};
await fs.writeFile(new URL('./native-compatibility.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
