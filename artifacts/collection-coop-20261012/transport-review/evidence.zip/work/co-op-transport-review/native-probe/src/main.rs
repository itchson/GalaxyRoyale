use game_core::{Game, InputFrame, Profile, co_op::{ParticipantId, PROTOCOL}};
fn main() {
    let session = ParticipantId::parse("000000000000000000000000000003e8").unwrap();
    let host = ParticipantId::parse("00000000000000000000000000000001").unwrap();
    let mut game = Game::new(Profile::default());
    game.begin_co_op(PROTOCOL, session, host).unwrap();
    for sequence in 0..3600 {
        game.submit_host_co_op_input(session, sequence, InputFrame {
            joystick: Some([1.0, 0.0]), fire: true, ..Default::default()
        }).unwrap();
        game.tick_co_op(session).unwrap();
        let snapshot = game.co_op_snapshot().unwrap();
        let mut offset = 0;
        loop {
            let page = game.co_op_entity_page(session, snapshot.revision, offset).unwrap();
            if page.entities.iter().any(|row| row.kind == "segment" && row.hull > 0.0 && row.max_hull == 0.0) {
                println!("{}", serde_json::to_string(&page).unwrap());
                eprintln!("actual public Game Segment page at tick{} revision{}", snapshot.tick, snapshot.revision);
                return;
            }
            match page.next_offset { Some(next) => offset = next, None => break }
        }
    }
    panic!("No live Segment encountered in 3600 authoritative ticks at {:?}", game.co_op_snapshot().unwrap().participants[0].position);
}
