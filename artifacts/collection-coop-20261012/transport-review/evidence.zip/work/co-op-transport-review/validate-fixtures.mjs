import fs from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
const [wirePath, fixtureDirectory, segmentPath] = process.argv.slice(2);
const { encode, decode, validatePayload } = await import(pathToFileURL(wirePath));
const read = async file => {
  const bytes = await fs.readFile(file);
  return { value: JSON.parse(bytes.toString("utf8")),
    sha256: createHash("sha256").update(bytes).digest("hex") };
};
const snapshot = await read(path.join(fixtureDirectory, "snapshot.json"));
const session = snapshot.value.session;
for (const [filename, kind] of [["snapshot.json", "snapshot"], ["entities.json", "body"], ["body.json", "body"], ["input.json", "input"]]) {
  const fixture = await read(path.join(fixtureDirectory, filename));
  const frame = { v: 1, session, seq: 1, kind, payload: fixture.value };
  const text = encode(frame);
  assert.deepEqual(decode(text), frame);
  console.log(JSON.stringify({ filename, sha256: fixture.sha256, accepted: true, framed_bytes: Buffer.byteLength(text) }));
}
const admissions = await read(path.join(fixtureDirectory, "admissions.json"));
for (const admission of admissions.value.filter(a => a.slot !== 0)) {
  validatePayload("admission", { accepted: true, slot: admission.slot, epoch: admission.epoch });
  const participant = snapshot.value.participants.find(p => p.id === admission.id);
  validatePayload("join", { local_seed: participant.local_seed, identity: participant.identity });
}
console.log(JSON.stringify({ filename: "admissions.json", sha256: admissions.sha256, accepted: true, guests: 7 }));
const segment = await read(segmentPath);
const frame = { v: 1, session: segment.value.session, seq: 1, kind: "body", payload: segment.value };
const text = encode(frame);
assert.deepEqual(decode(text), frame);
console.log(JSON.stringify({ filename: "actual-segment-page.json", sha256: segment.sha256, accepted: true,
  tick: segment.value.tick, revision: segment.value.revision, framed_bytes: Buffer.byteLength(text),
  segments: segment.value.entities.filter(e => e.kind === "segment").length }));
