import hashlib
import json
from pathlib import Path
import subprocess

own = Path(__file__).resolve().parents[2]
source = Path("C:/Users/mitch/.codex/worktrees/galaxy-audio-refinement/galaxy-royale")
commit = "38742784f6000135a68354750bdf0d3204334422"
sha = lambda data: hashlib.sha256(data).hexdigest()
paths = subprocess.check_output(["git", "diff", "--name-only", "5aa5cfa", commit], cwd=source).decode().splitlines()
paths += ["apps/coop/store.mjs", "apps/coop/server.mjs", "package.json", "pnpm-lock.yaml", "tsconfig.json"]
pins = []
for path in paths:
    blob = subprocess.check_output(["git", "show", f"{commit}:{path}"], cwd=source)
    raw = (source / path).read_bytes()
    assert raw.replace(b"\r\n", b"\n") == blob, path
    pins.append({"path": path, "git_lf_sha256": sha(blob), "git_lf_bytes": len(blob),
                 "raw_sha256": sha(raw), "raw_bytes": len(raw)})
folder = own / "work/co-op-transport-review"
evidence = []
for path in sorted(folder.rglob("*")):
    if path.is_file() and path.name not in {"manifest.json", "pin.py"}:
        data = path.read_bytes()
        evidence.append({"path": path.relative_to(own).as_posix(), "raw_sha256": sha(data), "raw_bytes": len(data)})
for path in sorted((own / "work/co-op-authority/serialization").glob("*.json")):
    data = path.read_bytes()
    evidence.append({"path": path.relative_to(own).as_posix(), "raw_sha256": sha(data), "raw_bytes": len(data)})
manifest = {"version": 1, "source_commit": commit,
            "native_authority_commit": "60934969913ad1e49a3ce4b2b63af514d890518b",
            "domain": "Source: committed Git LF and observed raw working bytes, LF equivalence verified. Evidence: raw bytes.",
            "source": pins, "evidence": evidence,
            "result": {"remaining_source_blockers": 0, "focused_pass": 27,
                       "browser_rtc_executed": False, "native_page_probe_tick": 1460}}
(folder / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
print(f"Verified {len(pins)} source/input pins and froze {len(evidence)} evidence pins.")
print("REVIEW", sha((folder / "REVIEW.md").read_bytes()))
print("manifest", sha((folder / "manifest.json").read_bytes()))
