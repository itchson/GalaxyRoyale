import fs from "node:fs/promises";
import { pathToFileURL } from "node:url";
const [wirePath, pagePath] = process.argv.slice(2);
const { encode } = await import(pathToFileURL(wirePath));
const page = JSON.parse(await fs.readFile(pagePath, "utf8"));
const frame = { v: 1, session: page.session, seq: 1, kind: "body", payload: page };
try {
  const text = encode(frame);
  console.log(JSON.stringify({ accepted: true, bytes: Buffer.byteLength(text),
    tick: page.tick, revision: page.revision, segments: page.entities.filter(e => e.kind === "segment") }));
} catch (error) {
  console.log(JSON.stringify({ accepted: false, code: error.code,
    tick: page.tick, revision: page.revision, segments: page.entities.filter(e => e.kind === "segment") }));
}
