import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { execFileSync, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const owner = 'C:/Users/mitch/.codex/worktrees/galaxy-audio-refinement/galaxy-royale';
const here = path.dirname(fileURLToPath(import.meta.url));
const commit = '4cb003b167672326d01e77928f084ae1f29689fa';
const parent = '38742784f6000135a68354750bdf0d3204334422';
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const read = p => fs.readFileSync(p);
const lf = b => Buffer.from(b.toString('utf8').replace(/\r\n/g, '\n'));
const git = (...args) => execFileSync('git', ['-C', owner, ...args]);
const ownerDirectory = path.join(owner, 'work/co-op-transport');
const manifestPath = path.join(ownerDirectory, 'manifest.json');
const frozen = JSON.parse(read(manifestPath));
assert.equal(frozen.commit, commit);
assert.equal(git('rev-parse', 'HEAD').toString().trim(), commit);
assert.equal(git('status', '--short').toString().trim(), '');
const changed = git('diff', '--name-only', parent, commit).toString().trim().split(/\r?\n/);
assert.equal(changed.length, 5);
const source = [];
for (const name of [...Object.keys(frozen.committed), ...Object.keys(frozen.inputs)]) {
  const raw = read(path.join(owner, name));
  const blob = git('show', `${commit}:${name}`);
  assert.ok(lf(raw).equals(blob), `LF source mismatch ${name}`);
  assert.equal(sha(raw), frozen.working[name] ?? frozen.inputs[name], name);
  if (frozen.committed[name]) assert.equal(sha(blob), frozen.committed[name], name);
  source.push({ path: name, changed: changed.includes(name), git_lf_sha256: sha(blob), git_lf_bytes: blob.length, raw_sha256: sha(raw), raw_bytes: raw.length });
}
const ownerEvidence = [];
for (const [name, expected] of Object.entries(frozen.evidence)) {
  const b = read(path.join(ownerDirectory, name));
  assert.equal(sha(b), expected, `Owner evidence mismatch ${name}`);
  ownerEvidence.push({ path: name, raw_sha256: sha(b), raw_bytes: b.length });
}
const ownerTests = read(path.join(ownerDirectory, 'native-open-test.log')).toString();
assert.match(ownerTests, /tests 29/);
assert.match(ownerTests, /pass 29/);
assert.match(ownerTests, /fail 0/);
const checks = JSON.parse(read(path.join(ownerDirectory, 'checks.json')));
assert.ok(checks.some(c => c.name === 'typecheck' && c.exit_code === 0));
assert.ok(checks.some(c => c.name === 'diff' && c.exit_code === 0));

const browserDirectory = path.join(ownerDirectory, 'browser-success');
const browserManifest = JSON.parse(read(path.join(browserDirectory, 'manifest.json')));
assert.equal(browserManifest.candidate, commit);
const browserPins = [];
for (const [name, expected] of Object.entries(browserManifest.pins)) {
  const b = read(path.join(browserDirectory, name));
  assert.equal(sha(b), expected, `Browser evidence mismatch ${name}`);
  browserPins.push({ path: name, raw_sha256: sha(b), raw_bytes: b.length });
}
const prepared = JSON.parse(read(path.join(browserDirectory, 'prepared-manifest.json')));
const inspection = JSON.parse(read(path.join(browserDirectory, 'inspection.json')));
for (const [name, pin] of Object.entries(inspection.candidatePins)) {
  assert.equal(sha(git('show', `${commit}:${name}`)), pin.committed_sha256, name);
  assert.equal(prepared.inputs[name], pin.prepared_raw_sha256, name);
  const integrated = git('show', `${inspection.integrated_head}:${name}`);
  assert.ok(integrated.equals(git('show', `${commit}:${name}`)), `Integrated source mismatch ${name}`);
}
const browserReports = browserPins.filter(p => /^d77.*\.json$/.test(p.path)).map(p => {
  const r = JSON.parse(read(path.join(browserDirectory, p.path)));
  assert.deepEqual(r.source_inputs, prepared.inputs);
  assert.ok(r.checks.every(c => c.passed === true));
  assert.equal(p.raw_sha256, p.path.match(/-([a-f0-9]{64})\.json$/)[1]);
  return { captured_at: r.captured_at, created: r.created, closed: r.closed, rtc_errors: r.rtc_errors, checks: r.checks.map(c => c.name) };
}).sort((a, b) => a.captured_at.localeCompare(b.captured_at));
assert.equal(browserReports.length, 5);
assert.deepEqual(browserReports.map(r => [r.created, r.closed]), [[2, 0], [2, 0], [2, 2], [4, 2], [4, 4]]);
assert.deepEqual(browserReports[2].rtc_errors, ['sctp-failure']);

const args = ['--experimental-transform-types', '--test', '--test-name-pattern', 'already-open incoming|RTC diagnostics|QA reports exclude', 'scripts/test/coop-transport.test.mjs', 'scripts/test/coop-transport-qa.test.mjs'];
const run = spawnSync(process.execPath, args, { cwd: owner, encoding: 'utf8', timeout: 30_000 });
const log = `$ ${process.execPath} ${args.join(' ')}\nCWD ${owner}\n${run.stdout ?? ''}${run.stderr ?? ''}\nEXIT ${run.status}\n`;
fs.writeFileSync(path.join(here, 'focused-test.log'), log);
assert.equal(run.status, 0, log);
assert.match(run.stdout, /tests 3/);
assert.match(run.stdout, /pass 3/);
assert.match(run.stdout, /fail 0/);
assert.equal(git('status', '--short').toString().trim(), '');
const result = {
  source_commit: commit, parent, changed_files: changed, source,
  owner_manifest_raw_sha256: sha(read(manifestPath)), owner_evidence: ownerEvidence,
  owner_checks: { focused_pass: 29, typecheck_exit: 0, diff_exit: 0 },
  independent_checks: { focused_pass: 3, exit_code: run.status, command: [process.execPath, ...args] },
  browser: { driver: 'Root', independent_browser_interaction: false, integrated_head: inspection.integrated_head, manifest_raw_sha256: sha(read(path.join(browserDirectory, 'manifest.json'))), pins: browserPins, reports: browserReports },
  domain: 'Source: exact Git LF blobs and observed raw working bytes; normalized LF equality checked. Evidence: raw bytes.'
};
fs.writeFileSync(path.join(here, 'inspection.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ source_commit: commit, source_inputs_verified: source.length, owner_evidence_verified: ownerEvidence.length, browser_evidence_verified: browserPins.length, independent_focused_pass: 3, changed_files: changed.length }));
