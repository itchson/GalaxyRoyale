# Independent co-op authority review — evolving source

Reviewed 2026-10-12 in the engine checkout `C:/Users/mitch/.codex/worktrees/galaxy-hud-navigation/galaxy-royale`, branch `codex/co-op-authority`, based on `5aa5cfaeb4db4e71511ac4dc251ce17d1b423923`. The authority implementation is dirty/uncommitted and continues to change. This is a source review; no native tests, builds, servers, transport sessions or browser co-op were executed by this reviewer. Final source pins and a test verdict await the author's freeze.

## Concrete review contributions

1. The initial draft's `Game.cancel_course()` cleared only the scalar destination, while session steering read the host `Pilot.destination` and synchronized it back. I reported this to Engine and Root. The reread now calls `cancel_co_op_course()`, clearing the host pilot's queued input and route while retaining velocity/throttle. Regression execution remains the author's pending gate.
2. Initial admission epochs restarted across sessions, while input submission accepted participant/epoch/sequence without a session token. I reported the delayed-message collision to Engine and Root. The reread now requires `expected_session` for join, host/guest input, leave, end, step, notice retrieval and entity/body pages. It rejects a different session before mutation. Session identifiers still must be unique and authenticated by the future transport; packet IDs are not authentication.
3. The author independently identified same-tick membership/page invalidation. The current draft uses a checked revision advanced on join, leave and step; both page APIs reject an obsolete revision. This is author work, not a reviewer-discovered issue.

## Source observations so far

- Session entry boxes the complete solo `Game`, runs a separate actual ECS world and restores the boxed value. The public persistent profile getter returns the saved solo profile while co-op is active.
- Guest admission accepts only a strict participant ID, nonzero local seed and a canonicalized identity. It reconstructs a factory profile; callers cannot submit XP, ranks, currency, inventory, health or position. Guests' owned RAICHO support is explicitly pending.
- Progression is disabled in the session, home mutation checks reject it, champion/tournament/site/credits actions are guarded, and session pickup handling grants no rewards. Primary weapons and ordinary enemy families are the declared stage scope.
- Nonblocking API consistency note sent to Engine: `acknowledge_license()` can return `Ok` in-session when onboarding exists, although `onboarding_fact()` correctly suppresses the mutation. If that action becomes exposed in-session, an explicit rejection would avoid a caller interpreting the no-op as completed training. No persistence leak was found.
- Actual created primary projectiles carry participant plus membership epoch; participant bullets skip every player body. Hostile bullets can hit actual pilot bodies. Departure/death removes that participant's owned shots. Destruction attribution is bounded to the actual hit owner.
- Participant count is at most eight; existing projectile, enemy, asteroid, particle and event limits remain. Entity output pages contain at most 64 rows, body output pages at most 1,024 occupied cells, and destruction notices at most 128. Page generation still collects/sorts current metadata and scans occupied cells; this is bounded output, not a zero-allocation or transport-throughput claim.

## Pending final review

Author freeze and actual focused native tests; exact restoration/control parity; stale session/membership/sequence cases; mutation rejection with unchanged saved bytes; eight-pilot targeting/friendly-fire/shot ownership; same-tick page revision rejection; invalid IDs/inputs/offsets; transport-authenticated source mapping; real browser multiplayer, phone and sustained-load measurements.
