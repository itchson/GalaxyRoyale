# Persisted collection screenshot review

Reviewed Root's supplied WebGPU JPEGs on 2026-10-12 with the image viewer: `hangar-after-webgpu.jpg`, `forge-after-webgpu.jpg` and `abilities-after-webgpu.jpg`, all under `C:/Users/mitch/Documents/ChatGPT/galaxy-royale/artifacts/collection-coop-20261012/`. Each persisted image is 1280×720. These are Root's actual QA-pilot captures, with one found hull/one ability, saved XP 8 and banked T1 2; they are not earned-progression or compact-layout acceptance. Exact file hashes are recorded separately.

The quiet card surfaces, compact native corporation/category glyphs and cyan active/equipped text have coherent hierarchy. No reproduced overlapping or truncated visible label was found in these three saved frames. The partly visible hardware row and lower ability actions require content scrolling; this review did not operate that scroll.

The concrete layout gap is the amount of content before the first collection action. Ability Collection repeats the page title beside Back, then shows RAICHO/XP, guidance and two full filter rows. Even with just one known ability, its action lies below the visible fold. Hull Collection repeats its outer heading inside content. I recommended dropping the duplicate headings and shortening guidance while retaining filters, core costs/reasons and action hitboxes. Root accepted this finding and owns the shell repair/re-capture.

Root independently identified the `.loadout-slot .upgrade-category` block rule overriding the intended compact icon/text row, and hardware currency alignment inherited from the global flex rule. Those are Root's findings and repairs, not additional defects attributed to this review.

No source was edited and no browser/native test was run for this image review. Final browser readability, compact scroll/action availability, undiscovered-entry exclusion and actual ownership transactions need their separate evidence.
