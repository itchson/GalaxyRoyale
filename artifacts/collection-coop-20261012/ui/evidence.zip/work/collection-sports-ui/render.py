"""Render retained actual UiScene packets; flat unlit approximation, not GPU."""
from pathlib import Path
import json
from PIL import Image, ImageDraw

folder = Path(__file__).resolve().parent
packet = json.loads((folder / "packets/collection.json").read_text(encoding="utf-8"))
factor = 4
view = packet["viewport"]
canvas = Image.new("RGB", (view[0] * factor, view[1] * factor), (3, 5, 9))
draw = ImageDraw.Draw(canvas)
for batch in packet["batches"]:
    for cell in batch["pixels"]:
        color = cell["color"].to_bytes(4, "little")
        if not color[3]:
            continue
        t = batch["transforms"][cell["transform"]]
        points = []
        for dx, dy in ((-.5, -.5), (.5, -.5), (.5, .5), (-.5, .5)):
            x, y = cell["local"][0] + dx, cell["local"][1] + dy
            points.append((factor * (t["a"][0] + t["a"][2] * x + t["b"][0] * y + view[0] / 2),
                           factor * (t["a"][1] + t["a"][3] * x + t["b"][1] * y + view[1] / 2)))
        draw.polygon(points, fill=tuple(color[:3]))
canvas = canvas.resize((view[0], view[1]), Image.Resampling.BOX)
canvas.save(folder / "native-software-collection.png")
print(json.dumps({"scope": "actual UiScene packet, 4x BOX flat unlit software; no DOM/GPU acceptance",
                  "cells": packet["cells"],
                  "transforms": sum(len(b["transforms"]) for b in packet["batches"])}))
