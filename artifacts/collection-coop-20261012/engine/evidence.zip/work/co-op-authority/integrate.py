from pathlib import Path
p=Path('crates/game_core/src/lib.rs')
s=p.read_text(encoding='utf-8')
start=s.index('    fn spawn_bullet(\n')
end=s.index('    fn update_chunks(',start)
old=s[start:end]
new=old.replace('''    ) {
        if self.world''','''    ) {
        self.spawn_bullet_entity(position, velocity, damage, player, hits);
    }

    fn spawn_bullet_entity(
        &mut self,
        position: Vec2,
        velocity: Vec2,
        damage: f32,
        player: bool,
        hits: u8,
    ) -> Option<Entity> {
        if self.world''',1).replace('''            return;
        }
        self.world.spawn((''','''            return None;
        }
        Some(self.world.spawn((''',1).replace('''        ));
    }
''','''        )))
    }
''',1)
s=s[:start]+new+s[end:]
s=s.replace('''        let stale: Vec<_> = self
            .chunks''','''        let participants = self.co_op_positions();
        let stale: Vec<_> = self
            .chunks''',1)
s=s.replace('''            .filter(|(x, y)| (x - center.0).abs() > 2 || (y - center.1).abs() > 2)''','''            .filter(|(x, y)| {
                if self.co_op.is_some() {
                    !participants.iter().flatten().any(|p| {
                        let px = (p.x / CHUNK).floor() as i32;
                        let py = (p.y / CHUNK).floor() as i32;
                        (x - px).abs() <= 2 && (y - py).abs() <= 2
                    })
                } else {
                    (x - center.0).abs() > 2 || (y - center.1).abs() > 2
                }
            })''',1)
s=s.replace('''                self.maybe_riveter(entity, regions::at(self.profile.seed, spawn));
                self.maybe_mote(entity, regions::at(self.profile.seed, spawn));''','''                if self.co_op.is_none() {
                    self.maybe_riveter(entity, regions::at(self.profile.seed, spawn));
                    self.maybe_mote(entity, regions::at(self.profile.seed, spawn));
                }''',1)
s=s.replace('''        if self.active_boss.is_none()
            && self.boss_timer''','''        if self.co_op.is_none()
            && self.active_boss.is_none()
            && self.boss_timer''',1)
# Nearest living nonsanctuary pilot; if all are safe, use nearest safe refuge.
s=s.replace('''    fn update_enemies(&mut self, player: Vec2, dt: f32) {
        let sanctuary''','''    fn update_enemies(&mut self, player: Vec2, dt: f32) {
        let participants = self.co_op_positions().map(|p| p.map(|p| (p, self.safe_zone_at(p))));
        let sanctuary''',1)
s=s.replace('''            brain.age += dt;
            brain.shot_timer -= dt;
            let delta = player - motion.position;''','''            let target = participants.iter().flatten()
                .filter(|(_, refuge)| refuge.is_none())
                .min_by(|(a, _), (b, _)| a.distance_squared(motion.position).total_cmp(&b.distance_squared(motion.position)))
                .or_else(|| participants.iter().flatten().min_by(|(a, _), (b, _)| a.distance_squared(motion.position).total_cmp(&b.distance_squared(motion.position))));
            let (player, safe, refuge_center) = target.map_or((player, safe, refuge_center), |(p, refuge)| (*p, refuge.is_some(), refuge.map_or(Vec2::ZERO, |zone| zone.0)));
            brain.age += dt;
            brain.shot_timer -= dt;
            let delta = player - motion.position;''',1)
s=s.replace('''            if let Some((_, target, local, is_segment, hit_position)) = nearest {
                if target == self.player {''','''            if let Some((_, target, local, is_segment, hit_position)) = nearest {
                if let Some(session) = &mut self.co_op {
                    session.hit_owner = self.world.get::<&co_op::ShotOwner>(entity).ok().map(|o| *o);
                }
                if self.co_op.is_some() && self.world.get::<&co_op::Pilot>(target).is_ok() {
                    self.hurt_co_op_pilot(target, bullet.damage, Some(local));
                } else if target == self.player {''',1)
s=s.replace('''                bullet.remaining_hits = bullet.remaining_hits.saturating_sub(1);''','''                if let Some(session) = &mut self.co_op { session.hit_owner = None; }
                bullet.remaining_hits = bullet.remaining_hits.saturating_sub(1);''',1)
start=s.index('        for (entity, m, a) in &actors {',s.index('    fn resolve_collisions'))
end=s.index('        // Light object-level asteroid impulses',start)
body=s[start:end]
s=s[:start]+'''        if self.co_op.is_some() {
            self.co_op_contacts(&actors, &segments);
        } else {
'''+body+'''        }
'''+s[end:]
s=s.replace('''        let ordinary = self.world.get::<&BossEncounter>(entity).ok().map(|b| *b);''','''        self.record_co_op_destruction(entity, kind);
        let ordinary = self.world.get::<&BossEncounter>(entity).ok().map(|b| *b);''',1)
# Participants need their own presentation metadata, not host corporation/shield.
s=s.replace('''        for (_, (motion, actor, body, boss, riveter, mote)) in self''','''        for (entity, (motion, actor, body, boss, riveter, mote)) in self''',1)
s=s.replace('''            let player_tint = |color| {
                player_presentation::tint(
                    color,
                    actor.health,
                    maximum_player_hull,
                    recent_player_damage,''','''            let pilot = self.world.get::<&co_op::Pilot>(entity).ok();
            let player_hull = pilot.as_ref().map_or(maximum_player_hull, |p| p.stats.hull);
            let damage_time = pilot.as_ref().map_or(recent_player_damage, |p| if p.invulnerability > 0.45 { 0.45 } else { p.since_damage });
            let corporation = pilot.as_ref().map_or_else(|| self.profile.identity.as_ref().map(|id| id.corporation), |p| p.spec.identity.as_ref().map(|id| id.corporation));
            let selected_ship = pilot.as_ref().map_or(self.profile.campaign.selected_ship, |p| p.selected_ship);
            let shield = pilot.as_ref().map_or(self.shield, |p| p.shield);
            let player_tint = |color| {
                player_presentation::tint(
                    color,
                    actor.health,
                    player_hull,
                    damage_time,''',1)
s=s.replace('''                && self.profile.campaign.selected_ship == 0
                && self.profile.identity.as_ref().is_some_and(|identity| {''','''                && selected_ship == 0
                && corporation.is_some_and(|corporation| {''',1)
s=s.replace('''                        identity.corporation,
                        raicho_fine::DrawInput''','''                        corporation,
                        raicho_fine::DrawInput''',1)
s=s.replace('''                if self.throttle > 0.03 {''','''                if entity == self.player && self.throttle > 0.03 {''',1)
s=s.replace('''                if self.shield > 0.0 {''','''                if shield > 0.0 {''',1)
s=s.replace('''rgba(92, 181, 255, if self.since_damage < 0.3 { 210 } else { 65 })''','''rgba(92, 181, 255, if damage_time < 0.3 { 210 } else { 65 })''',1)
p.write_text(s,encoding='utf-8',newline='\n')
Path('crates/game_core/src/co_op_tests.rs').write_text('// Tests are added before the final source freeze.\n',encoding='utf-8',newline='\n')
