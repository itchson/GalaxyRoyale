import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[2]
commit = "60934969913ad1e49a3ce4b2b63af514d890518b"
sources = ["co_op.rs", "co_op_control.rs", "co_op_tests.rs", "lib.rs",
           "ship_progression.rs", "campaign_runtime.rs", "identity.rs"]
inputs = ["Cargo.lock", "crates/game_core/Cargo.toml",
          "crates/game_core/src/campaign.rs", "crates/game_core/src/shield_progression.rs",
          "crates/game_core/src/pixel_assets.rs", "crates/game_core/src/regions.rs",
          "crates/game_core/src/segmented.rs", "crates/game_core/src/training.rs",
          "crates/engine_core/src/frame.rs", "crates/engine_core/src/pixels.rs"]
paths = ["crates/game_core/src/" + name for name in sources] + inputs
sha = lambda data: hashlib.sha256(data).hexdigest()
pins = []
for path in paths:
    raw = (root / path).read_bytes()
    blob = subprocess.check_output(["git", "show", f"{commit}:{path}"], cwd=root)
    assert raw.replace(b"\r\n", b"\n") == blob, path
    pins.append({"path": path, "raw_sha256": sha(raw), "raw_bytes": len(raw),
                 "git_lf_sha256": sha(blob), "git_lf_bytes": len(blob),
                 "kind": "owned_source" if path in paths[:7] else "unchanged_input"})
evidence = []
folder = root / "work/co-op-authority"
for path in sorted(folder.rglob("*")):
    if path.is_file() and (path.suffix == ".log" or path.parent.name == "serialization"
                          or path.name == "HANDOFF.md"):
        data = path.read_bytes()
        evidence.append({"path": path.relative_to(root).as_posix(),
                         "raw_sha256": sha(data), "raw_bytes": len(data)})
manifest = {"version": 1, "commit": commit,
            "parent": "5aa5cfaeb4db4e71511ac4dc251ce17d1b423923",
            "source_domain": "Committed Git LF bytes and observed raw working bytes are both pinned; LF equivalence verified.",
            "evidence_domain": "Observed raw bytes; do not normalize logs or serializer fixtures.",
            "source": pins, "evidence": evidence,
            "checks": {"focused_pass": 17, "focused_ignored_explicit_export": 1,
                       "full_core_pass": 401, "full_core_ignored_explicit_exports": 4,
                       "serializer_export_pass": 1, "native_strict_clippy": True}}
(folder / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
print(f"Verified {len(pins)} committed source/input pins and froze {len(evidence)} evidence pins.")
print("HANDOFF", sha((folder / "HANDOFF.md").read_bytes()))
print("manifest", sha((folder / "manifest.json").read_bytes()))
