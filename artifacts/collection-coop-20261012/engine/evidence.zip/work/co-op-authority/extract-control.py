from pathlib import Path
root=Path('.')
p=root/'crates/game_core/src/lib.rs'
s=p.read_text(encoding='utf-8')
start=s.index('    fn control(&mut self, input: &InputFrame, dt: f32) {')
end=s.index('        self.exhaust_timer -= dt;',start)
block=s[start:end]
body=block[block.index('        let aim = input'):block.index('        *self.world.get::<&mut Motion>(self.player).unwrap() = motion;')]
# Identical control math, with the two pilot-owned scalars supplied explicitly.
body=body.replace('self.destination','(*destination)').replace('self.throttle','(*throttle)')
helper='//! Shared solo/session steering; caller supplies one actual ECS Motion.\nuse super::*;\n\npub(super) fn control_motion(\n    mut motion: Motion,\n    throttle: &mut f32,\n    destination: &mut Option<Vec2>,\n    input: &InputFrame,\n    stats: Stats,\n    dt: f32,\n) -> Motion {\n'
# Destination processing preceded the old local Motion binding.
destination=block[block.index('        if let Some(point)'):block.index('        let mut motion =')].replace('self.destination','(*destination)')
helper+=destination+body+'    motion\n}\n'
(root/'crates/game_core/src/co_op_control.rs').write_text(helper,encoding='utf-8',newline='\n')
replacement='''    fn control(&mut self, input: &InputFrame, dt: f32) {
        let stats = Stats::from_profile(&self.profile);
        let motion = co_op_control::control_motion(
            *self.world.get::<&Motion>(self.player).unwrap(),
            &mut self.throttle,
            &mut self.destination,
            input,
            stats,
            dt,
        );
        *self.world.get::<&mut Motion>(self.player).unwrap() = motion;
'''
s=s[:start]+replacement+s[end:]
s=s.replace('pub mod components;','pub mod components;\npub mod co_op;\nmod co_op_control;\n#[cfg(test)]\nmod co_op_tests;',1)
s=s.replace('    world: World,\n    player: Entity,','    world: World,\n    co_op: Option<co_op::Session>,\n    player: Entity,',1)
s=s.replace('            world,\n            player,','            world,\n            co_op: None,\n            player,',1)
s=s.replace('''    pub fn profile(&self) -> &Profile {
        &self.profile
    }''','''    pub fn profile(&self) -> &Profile {
        self.co_op.as_ref().map_or(&self.profile, |session| session.solo.profile())
    }''',1)
s=s.replace('        !self.diagnostic_scene\n','        self.co_op.is_none()\n            && !self.diagnostic_scene\n',1)
s=s.replace('        if self.paused || !dt.is_finite() || dt <= 0.0 {','        if self.co_op.is_some() || self.paused || !dt.is_finite() || dt <= 0.0 {',1)
s=s.replace('''    pub fn reset_to_dock(&mut self) {
        self.discard_cargo''','''    pub fn reset_to_dock(&mut self) {
        if self.end_co_op() {
            return;
        }
        self.discard_cargo''',1)
s=s.replace('''    pub fn diagnostic(&mut self, command: &str) {
        if matches!''','''    pub fn diagnostic(&mut self, command: &str) {
        if self.co_op.is_some() {
            return;
        }
        if matches!''',1)
p.write_text(s,encoding='utf-8',newline='\n')
p=root/'crates/game_core/src/ship_progression.rs'
s=p.read_text(encoding='utf-8').replace('''    pub(super) fn require_home(&self) -> Result<(), String> {
        if self.position()''','''    pub(super) fn require_home(&self) -> Result<(), String> {
        if self.co_op.is_some() {
            return Err("Dock inventory is unavailable in this unfinished co-op session.".into());
        }
        if self.position()''',1)
p.write_text(s,encoding='utf-8',newline='\n')
p=root/'crates/game_core/src/campaign_runtime.rs'
s=p.read_text(encoding='utf-8').replace('''    pub fn acknowledge_credits(&mut self) {
        if self.profile''','''    pub fn acknowledge_credits(&mut self) {
        if !self.progression_enabled() {
            return;
        }
        if self.profile''',1)
p.write_text(s,encoding='utf-8',newline='\n')
