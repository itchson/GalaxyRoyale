from pathlib import Path
p=Path('crates/game_core/src/co_op.rs')
s=p.read_text(encoding='utf-8')
s=s.replace('    StaleMembership,','    StaleSession,\n    StaleMembership,',1)
s=s.replace('''    pub fn join_co_op(&mut self, mut spec: ParticipantSpec) -> Result<Admission, Error> {
        let profile''','''    pub fn join_co_op(&mut self, expected_session: ParticipantId, mut spec: ParticipantSpec) -> Result<Admission, Error> {
        self.check_co_op_session(expected_session)?;
        let profile''',1)
s=s.replace('''    pub fn submit_host_co_op_input(
        &mut self,
        sequence: u32,''','''    pub fn submit_host_co_op_input(
        &mut self,
        expected_session: ParticipantId,
        sequence: u32,''',1)
s=s.replace('''        let host = self.co_op.as_ref().ok_or(Error::NoSession)?.host;
        self.submit_co_op_input''','''        self.check_co_op_session(expected_session)?;
        let host = self.co_op.as_ref().ok_or(Error::NoSession)?.host;
        self.submit_co_op_input''',1)
s=s.replace('''    pub fn submit_guest_co_op_input(
        &mut self,
        id: ParticipantId,''','''    pub fn submit_guest_co_op_input(
        &mut self,
        expected_session: ParticipantId,
        id: ParticipantId,''',1)
s=s.replace('''        if self.co_op.as_ref().ok_or(Error::NoSession)?.host == id {''','''        self.check_co_op_session(expected_session)?;
        if self.co_op.as_ref().ok_or(Error::NoSession)?.host == id {''',1)
s=s.replace('''    pub fn leave_co_op(&mut self, id: ParticipantId, epoch: u32) -> Result<(), Error> {
        let host''','''    pub fn leave_co_op(&mut self, expected_session: ParticipantId, id: ParticipantId, epoch: u32) -> Result<(), Error> {
        self.check_co_op_session(expected_session)?;
        let host''',1)
s=s.replace('''            self.end_co_op();''','''            self.restore_co_op();''',1)
s=s.replace('''    pub fn end_co_op(&mut self) -> bool {
        let Some(session)''','''    pub fn end_co_op(&mut self, expected_session: ParticipantId) -> Result<(), Error> {
        self.check_co_op_session(expected_session)?;
        self.restore_co_op();
        Ok(())
    }
    fn check_co_op_session(&self, expected: ParticipantId) -> Result<(), Error> {
        let session = self.co_op.as_ref().ok_or(Error::NoSession)?;
        if session.id != expected { return Err(Error::StaleSession); }
        Ok(())
    }
    pub(super) fn restore_co_op(&mut self) -> bool {
        let Some(session)''',1)
s=s.replace('''    pub fn tick_co_op(&mut self) -> Result<(), Error> {
        if self.paused''','''    pub fn tick_co_op(&mut self, expected_session: ParticipantId) -> Result<(), Error> {
        self.check_co_op_session(expected_session)?;
        if self.paused''',1)
s=s.replace('''    pub fn take_co_op_destructions(&mut self) -> Vec<Destruction> {
        self.co_op.as_mut().map_or_else(Vec::new, |session|''','''    pub fn take_co_op_destructions(&mut self, expected_session: ParticipantId) -> Result<Vec<Destruction>, Error> {
        self.check_co_op_session(expected_session)?;
        Ok(self.co_op.as_mut().map_or_else(Vec::new, |session|''',1)
# rustfmt expanded the prior closure expression; replace its exact final close.
start=s.index('    pub fn take_co_op_destructions(')
end=s.index('    pub fn co_op_snapshot(',start)
chunk=s[start:end]
chunk=chunk.replace('''        })
    }
''','''        }))
    }
''',1)
s=s[:start]+chunk+s[end:]
s=s.replace('''    pub fn co_op_entity_page(&self, revision: u32, offset: usize)''','''    pub fn co_op_entity_page(&self, expected_session: ParticipantId, revision: u32, offset: usize)''',1)
s=s.replace('''    pub fn co_op_body_page(
        &self,
        revision: u32,''','''    pub fn co_op_body_page(
        &self,
        expected_session: ParticipantId,
        revision: u32,''',1)
for name in ['co_op_entity_page','co_op_body_page']:
    start=s.index('    pub fn '+name+'(')
    at=s.index('        let session = self.co_op.as_ref().ok_or(Error::NoSession)?;',start)
    s=s[:at]+'        self.check_co_op_session(expected_session)?;\n'+s[at:]
# Cancel local course without touching another participant or current momentum.
at=s.index('    fn sync_co_op_host(&mut self) {')
s=s[:at]+'''    pub(super) fn cancel_co_op_course(&mut self) {
        if let Ok(mut pilot) = self.world.get::<&mut Pilot>(self.player) {
            pilot.destination = None;
            pilot.input = InputFrame::default();
        }
    }
'''+s[at:]
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('crates/game_core/src/lib.rs')
s=p.read_text(encoding='utf-8').replace('if self.end_co_op() {','if self.restore_co_op() {',1)
s=s.replace('''    pub fn cancel_course(&mut self) {
        self.destination = None;''','''    pub fn cancel_course(&mut self) {
        self.cancel_co_op_course();
        self.destination = None;''',1)
p.write_text(s,encoding='utf-8',newline='\n')
