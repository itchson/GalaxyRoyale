from pathlib import Path
p=Path('crates/game_core/src/co_op.rs')
s=p.read_text(encoding='utf-8')
s=s.replace('    tick: u32,\n    next_epoch:', '    tick: u32,\n    revision: u32,\n    next_epoch:',1)
# Add revision to snapshot and page structs only, not each destruction.
for name in ['Snapshot','EntityPage','BodyPage']:
    start=s.index('pub struct '+name+' {')
    at=s.index('    pub tick: u32,',start)+len('    pub tick: u32,')
    s=s[:at]+'\n    pub revision: u32,'+s[at:]
s=s.replace('''            || self.position().length_squared() > DOCK_RADIUS * DOCK_RADIUS
            || !self.world.get::<&Actor>(self.player).is_ok_and(|a| a.health > 0.0)''','''            || !self.position().is_finite()
            || self.position().length_squared() > DOCK_RADIUS * DOCK_RADIUS
            || !self.world.get::<&Actor>(self.player).is_ok_and(|a| a.health.is_finite() && a.health > 0.0)
            || !self.world.get::<&PixelBody>(self.player).is_ok_and(|body| body.occupied_count() > 0)''',1)
s=s.replace('host, tick: 0, next_epoch: 2','host, tick: 0, revision: 0, next_epoch: 2',1)
s=s.replace('''        let next = epoch.checked_add(1).ok_or(Error::Exhausted)?;
        let admission''','''        let next = epoch.checked_add(1).ok_or(Error::Exhausted)?;
        let revision = session.revision.checked_add(1).ok_or(Error::Exhausted)?;
        let admission''',1)
s=s.replace('''        self.co_op.as_mut().unwrap().next_epoch = next;''','''        let session = self.co_op.as_mut().unwrap();
        session.next_epoch = next;
        session.revision = revision;''',1)
s=s.replace('''        if id == host { self.end_co_op(); return Ok(()); }
        let shots''','''        if id == host { self.end_co_op(); return Ok(()); }
        let revision = self.co_op.as_ref().unwrap().revision.checked_add(1).ok_or(Error::Exhausted)?;
        let shots''',1)
s=s.replace('''        let _ = self.world.despawn(entity);
        Ok(())
    }
    /// Restores''','''        let _ = self.world.despawn(entity);
        self.co_op.as_mut().unwrap().revision = revision;
        Ok(())
    }
    /// Restores''',1)
s=s.replace('''        session.tick = session.tick.checked_add(1).ok_or(Error::Exhausted)?;
        let tick''','''        let next_tick = session.tick.checked_add(1).ok_or(Error::Exhausted)?;
        let next_revision = session.revision.checked_add(1).ok_or(Error::Exhausted)?;
        session.tick = next_tick;
        session.revision = next_revision;
        let tick''',1)
s=s.replace('tick: session.tick, progression: false', 'tick: session.tick, revision: session.revision, progression: false',1)
s=s.replace('pub fn co_op_entity_page(&self, tick: u32,', 'pub fn co_op_entity_page(&self, revision: u32,',1)
s=s.replace('pub fn co_op_body_page(&self, tick: u32,', 'pub fn co_op_body_page(&self, revision: u32,',1)
s=s.replace('if session.tick != tick { return Err(Error::StaleSnapshot); }','if session.revision != revision { return Err(Error::StaleSnapshot); }')
s=s.replace('EntityPage { session: session.id, tick, offset,','EntityPage { session: session.id, tick: session.tick, revision, offset,',1)
s=s.replace('BodyPage { session: session.id, tick, id:', 'BodyPage { session: session.id, tick: session.tick, revision, id:',1)
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('crates/game_core/src/co_op_control.rs')
s=p.read_text(encoding='utf-8').replace('= (*destination) {','= *destination {')
p.write_text(s,encoding='utf-8',newline='\n')
