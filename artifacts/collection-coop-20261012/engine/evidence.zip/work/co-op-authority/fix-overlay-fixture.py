from pathlib import Path
p=Path('crates/game_core/src/co_op_tests.rs')
s=p.read_text(encoding='utf-8')
old='''    assert!(
        game.world
            .get::<&Motion>(game.player)
            .unwrap()
            .velocity
            .length()
            < previous.length()
    );
}'''
new='''    assert!(game.world.get::<&Pilot>(game.player).unwrap().throttle < 1.0);
    // Existing course steering may keep accelerating briefly while throttle
    // decays. Do not invent an immediate velocity stop for a live overlay.
    for _ in 0..120 { game.tick_co_op(session()).unwrap(); }
    assert!(game.world.get::<&Motion>(game.player).unwrap().velocity.length() < previous.length() * 0.01);
}'''
assert old in s
s=s.replace(old,new,1)
p.write_text(s,encoding='utf-8',newline='\n')
