"""Native packets sampled offline with the current radial soft-material equations.

This is a NumPy/Pillow software model, not WGSL execution or GPU acceptance.
Physical raster is 2x logical; 2x offline sampling approximates pixel coverage.
The hard-only column filters the candidate's unchanged filament packets.
"""
import json
import math
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw

BASE = Path(__file__).resolve().parent
RASTER = 2
SAMPLES = 2
SIZE = (256, 180)


def render(view, hard_only=False):
    scale = RASTER * SAMPLES
    image = np.zeros((SIZE[1]*scale, SIZE[0]*scale, 3), np.float32)
    image[:] = (np.array([3, 4, 6])/255)**2.2
    for cell in view['cells']:
        soft = cell['material'][1] < 0
        if hard_only and soft:
            continue
        basis = np.column_stack([cell['basis_x'], cell['basis_y']])*RASTER
        area = abs(np.linalg.det(basis))
        coverage = 1.0
        if soft:
            covariance = basis @ basis.T
            xx, yy, xy = covariance[0,0], covariance[1,1], covariance[0,1]
            largest = .5*(xx+yy+math.sqrt((xx-yy)**2+4*xy*xy))
            smallest = area*area/max(largest, 1e-20)
            if smallest < 4:
                variance = 4-smallest
                expanded_area = math.sqrt(max(area*area+variance*(xx+yy)+variance**2, 1e-20))
                xx += variance
                yy += variance
                denominator = math.sqrt(max(xx+yy+2*expanded_area, 1e-20))
                basis = np.array([[xx+expanded_area,xy],[xy,yy+expanded_area]])/denominator
                coverage = np.clip(area/expanded_area, 0, 1)
        basis *= SAMPLES
        center = np.array(cell['center'])*scale
        corners = np.array([[-.5,-.5],[.5,-.5],[.5,.5],[-.5,.5]]) @ basis.T + center
        left=max(0,math.floor(corners[:,0].min()))
        right=min(image.shape[1],math.ceil(corners[:,0].max()))
        top=max(0,math.floor(corners[:,1].min()))
        bottom=min(image.shape[0],math.ceil(corners[:,1].max()))
        if left>=right or top>=bottom:
            continue
        y,x=np.mgrid[top:bottom,left:right]
        uv=np.stack([x+.5-center[0],y+.5-center[1]],axis=-1) @ np.linalg.inv(basis).T
        inside=(abs(uv)<=.5).all(axis=-1)
        alpha=cell['rgba'][3]/255*np.ones(inside.shape,dtype=np.float32)
        if soft:
            radial=np.maximum(0,1-(uv*uv).sum(axis=-1)*4)
            alpha*=radial*radial*coverage
        alpha*=inside
        emission=max(0,-cell['material'][1]-1) if soft else cell['material'][1]
        color=np.minimum(1,(np.array(cell['rgba'][:3])/255)**2.2*(1+.3*emission))
        patch=image[top:bottom,left:right]
        patch[:]=patch*(1-alpha[...,None])+color*alpha[...,None]
    image=image.reshape(SIZE[1]*RASTER,SAMPLES,SIZE[0]*RASTER,SAMPLES,3).mean(axis=(1,3))
    encoded=np.clip(image,0,1)**(1/2.2)
    rgb=(encoded*255+.5).astype(np.uint8)
    return Image.fromarray(rgb), {'mean_rgb':rgb.mean(axis=(0,1)).tolist(),'max_rgb':rgb.max(axis=(0,1)).tolist()}


packets=[json.loads(p.read_text()) for p in sorted((BASE/'packets').glob('*.json'))]
assert len(packets)==6
out=BASE/'software'
out.mkdir(exist_ok=True)
tile=(SIZE[0]*RASTER,SIZE[1]*RASTER)
sheet=Image.new('RGB',(tile[0]*4,32+len(packets)*(tile[1]+24)),(6,8,12))
draw=ImageDraw.Draw(sheet)
draw.text((6,8),'Actual native packets / SOFTWARE radial material model / not GPU or browser',fill=(185,190,199))
summary=[]
for row,packet in enumerate(packets):
    y=32+row*(tile[1]+24)
    baseline,_=render(packet['views'][1],True)
    sheet.paste(baseline,(0,y))
    draw.text((4,y+tile[1]+4),'Filaments only / z1 (same candidate packets)',fill=(153,159,168))
    for col,view in enumerate(packet['views'],1):
        image,metrics=render(view)
        name=f"low{packet['reduced']}-t{packet['time']}-z{view['zoom']}.png"
        image.save(out/name)
        sheet.paste(image,(col*tile[0],y))
        draw.text((col*tile[0]+4,y+tile[1]+4),f"{'low' if packet['reduced'] else 'full'} t{packet['time']} z{view['zoom']} / {packet['quads']} cells",fill=(165,172,185))
        summary.append({'file':name,'reduced':packet['reduced'],'time':packet['time'],'zoom':view['zoom'],'quads':packet['quads'],**metrics})
sheet.save(BASE/'native-software-contact.png')
(BASE/'software-summary.json').write_text(json.dumps({'scope':__doc__,'physical_raster_scale':RASTER,'offline_samples_per_axis':SAMPLES,'views':summary},indent=2)+'\n',newline='\n')
print('Rendered 6 native packets / 18 actual projected views plus 6 isolated filament views; offline soft material model only')
