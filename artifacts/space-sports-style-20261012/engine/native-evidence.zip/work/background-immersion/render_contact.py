from pathlib import Path
import json, numpy as np
from PIL import Image,ImageDraw
B=Path('work/background-immersion')
# Reuse only the owned historical offline raster function, with hard cells.
s=Path('work/deep-nebula-gas/render_contact.py').read_text(encoding='utf-8').split('packets=[json.loads')[0]
ns={ '__file__':str(B/'render_contact.py') };exec(s,ns);ns['SIZE']=(192,144);ns['RASTER']=1;ns['SAMPLES']=4
render=ns['render']
def image_view(v):
 cells=[]
 for c in v['cells']:
  p=np.array(c['corners']);cells.append({'center':p.mean(axis=0),'basis_x':p[1]-p[0],'basis_y':p[3]-p[0],'rgba':c['rgba'],'material':c.get('material',[0,0])})
 return render({'cells':cells})[0]
rows=[]
for k in [0,2]:
 for low in [False,True]:
  old=json.loads((B/'before'/f'motif-{k}-reduced-{str(low).lower()}-time-0.json').read_text())
  new=json.loads((B/'after-final'/f'motif-{k}-reduced-{str(low).lower()}-time-0.json').read_text())
  rows.append((f'{new["kind"]} {"low" if low else "full"}',[(old['views'][1],'Before z1'),*[(v,f'After z{v["zoom"]:.1f}') for v in new['views']]]))
for k in range(4):
 for low in [False,True]:
  new=json.loads((B/'regions'/f'region-{k}-reduced-{str(low).lower()}.json').read_text());rows.append((f'{new["kind"]} {"low" if low else "full"} / {new["quads"]} cells',[(v,f'z{v["zoom"]:.1f}') for v in new['views']]))
sheet=Image.new('RGB',(192*4,40+len(rows)*170),(8,10,14));d=ImageDraw.Draw(sheet)
d.text((4,8),'Actual native cells / offline linear-alpha 4x samples / NOT GPU or browser',fill=(190,194,205))
(B/'software-final').mkdir(exist_ok=True)
for i,(title,views) in enumerate(rows):
 y=40+i*170
 for j,(v,label) in enumerate(views):
  im=image_view(v);sheet.paste(im,(j*192,y));d.text((j*192+3,y+146),f'{title} {label}',fill=(177,183,196));im.save(B/'software-final'/f'row{i}-column{j}.png')
sheet.save(B/'native-software-contact-final.png');print('12 packet rows, 40 projected views; native software contact ready')
