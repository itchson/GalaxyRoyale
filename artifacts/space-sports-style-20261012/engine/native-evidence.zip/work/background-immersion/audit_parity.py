from pathlib import Path
import json,subprocess,hashlib
B=Path('work/background-immersion');old=subprocess.check_output(['git','show','4e014bff3a84b356c5254b4291560e38accef64d:crates/game_core/src/cosmic_background.rs']).decode('utf-8');new=Path('crates/game_core/src/cosmic_background.rs').read_text(encoding='utf-8')
def block(s,key,nextkey):return s[s.index(key):s.index(nextkey,s.index(key))]
sections=[('gas birth/cache helpers','fn noise(', '/// Fixed two-unit'),('hard nebula parts','    nebula: Pair::new(', '    nova_shell: Pair::new('),('gas extraction','fn gas_flow(', 'fn motif_cost(')]
for name,a,b in sections:assert block(old,a,b)==block(new,a,b),name
oldr=subprocess.check_output(['git','show','4e014bff3a84b356c5254b4291560e38accef64d:crates/game_core/src/regions.rs']).decode('utf-8');newr=Path('crates/game_core/src/regions.rs').read_text(encoding='utf-8');mark='// Small local-cell templates';assert oldr.split(mark)[0]==newr.split(mark)[0], 'region gameplay prefix changed'
assert block(old,'fn stellar_system(', 'fn draw_system(')==block(new,'fn stellar_system(', 'fn draw_system(')
nebula=[]
for low in [False,True]:
 for time in [0,18]:
  name=f'motif-1-reduced-{str(low).lower()}-time-{time}.json';a=json.loads((B/'before'/name).read_text());b=json.loads((B/'after-final'/name).read_text());assert a['quads']==b['quads'] and a['transforms']==b['transforms']
  for av,bv in zip(a['views'],b['views']):
   assert av['zoom']==bv['zoom'];assert len(av['cells'])==len(bv['cells'])
   for ac,bc in zip(av['cells'],bv['cells']):assert ac['corners']==bc['corners'] and ac['rgba']==bc['rgba']
  nebula.append({'file':name,'cells':a['quads'],'projected_views':len(a['views']),'all_corners_rgba_exact':True})
summary={'base':'4e014bff3a84b356c5254b4291560e38accef64d','candidate':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'region_authoritative_prefix_byte_equal_LF':True,'stellar_origin_nodes_function_byte_equal_LF':True,'approved_nebula_source_sections_equal': [x[0] for x in sections],'approved_nebula_packets':nebula,'motifs':[]}
for stage in ['before','after-final','regions']:
 for p in sorted((B/stage).glob('*.json')):
  d=json.loads(p.read_text());assert all(len(v['cells'])==d['quads'] for v in d['views']);summary['motifs'].append({'file':str(p.relative_to(B)).replace('\\','/'),'kind':d['kind'],'low':d['reduced'],'time':d['time'],'quads':d['quads'],'transforms':d['transforms'],'views':len(d['views'])})
(B/'parity-and-counts.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n');print('PASS exact region gameplay prefix / seeded stellar positions / approved nebula source+4 packets+12 views;32 packet sets counts validated')
for row in summary['motifs']:
 if row['time']==0:print(row['file'],row['quads'],row['transforms'])
