import hashlib,json,subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=BASE.parent.parent
m=json.loads((BASE/'manifest.json').read_text(encoding='utf-8'))
sha=lambda b:hashlib.sha256(b).hexdigest()
for p in m['inputs']:
 raw=(ROOT/p['path']).read_bytes();blob=subprocess.check_output(['git','show',m['commit']+':'+p['path']],cwd=ROOT)
 assert raw.replace(b'\r\n',b'\n')==blob,p['path']
 assert sha(blob)==p['committed_LF_sha256'],p['path']
 assert sha(raw)==p['working_raw_sha256'],p['path']
for p in m['files']:
 raw=(ROOT/p['path']).read_bytes();assert len(raw)==p['bytes'] and sha(raw)==p['sha256'],p['path']
print(f"PASS {len(m['inputs'])} source pins and {len(m['files'])} raw evidence pins at {m['commit']}")
